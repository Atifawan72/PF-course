﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace app
{
    internal class cars
    {
        
        public string name;
        public string model;
        public string year;

        public cars(string cname, string cmodel, string cyear)
        {
            name = cname;
            model = cmodel;
            year = cyear;
            
           
           

        }
       
            
        }
    
    }




