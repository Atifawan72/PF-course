Week for the programminf fundamental course. 
