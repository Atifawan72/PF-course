#include<iostream>
using namespace std;
int main(){
cout<<"                    oooooooooooo    oo       oooooo           \n";
cout<<"                  oo        oo     oo oo     oo  oo         \n"; 
cout<<"                   oooo     oo    oo   oo    oooo           \n";
cout<<"                      oo    oo   ooooooooo   oo  oo         \n";
cout<<"                       oo   oo  oo       oo  oo   oo        \n";
cout<<"             ooooooooooooo  oo  oo       oo  oo    ooooooooo      \n";
cout<<"                                                        \n";
cout<<"                                                        \n";
cout<<"               oo     oo    oo   oo      ooooo        ooooooo                   \n";
cout<<"               oo     oo    oo  oo oo    oo  oo      oo                     \n";
cout<<"               oo     oo    oo ooooooo   ooooo         oooo                    \n";
cout<<"                 ooo ooooo oo oo     oo  oo   oo           oo                \n";
cout<<"                   oo    oo   oo     oo  oo    ooooooooooooo                      \n";
}