#include <iostream>

int main() {
    std::cout << "       __n__n__  \n";
    std::cout << "   .------`-\\00/-'\n";
    std::cout << "  /  ##  ## (oo) \n";
    std::cout << " / \\## __   ./   \n";
    std::cout << "    |//YY \\|/    \n";
    std::cout << "     |||   |||\n";

    return 0;
}
