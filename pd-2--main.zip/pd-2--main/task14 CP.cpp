#include<iostream.
using namespace std;
int main(){
cout<<"  ';-.       ----' ;                                 \n";
cout<<"   . . !-----/----/                                 \n";
cout<<"       !          /                          \n";
cout<<"      /o       o  !        / _                             \n";
cout<<"      !           !       /                   \n";
cout<<"        !  -'-       !   /   _                      \n";
cout<<"        .            ! /                         \n";
cout<<"        /  ..    / / !:     _                         \n";
cout<<"       c_/      c_/  !     _                        \n";
cout<<"          !           !    _                      \n";
cout<<"          !           / _                          \n";
cout<<"     >                /                             \n";
cout<<"        c----------/                           \n";
cout<<"         c_, ------                                       \n";
cout<<"                                                \n";
cout<<"                                               \n";

}
