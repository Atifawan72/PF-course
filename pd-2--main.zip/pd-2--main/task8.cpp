#include<iostream>
using namespace std;
int main(){
cout<<" ----------------------------         \n";
cout<<"  o  ^__^        \n";
cout<<"    o (oo) /__________      \n";
cout<<"       (__)/             )*//   \n";
cout<<"        //-------//   \n";
cout<<"        //----//  \n";
cout<<"         ----- \n";
}