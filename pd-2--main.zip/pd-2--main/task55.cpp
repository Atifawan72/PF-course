#include <iostream>
using namespace std;
int main() {
    cout << "oooooooooo   o       oooooooo8 oooo     oooo      o      oooo   oooo\n";
    cout << " 888    888 888    o888     88  8888o   888      888      8888o  88 \n";
    cout << " 888oooo88 8  88   888          88 888o8 88     8  88     88 888o88 \n";
    cout << " 888      8oooo88  888o     oo  88  888  88    8oooo88    88   8888 \n";
    cout << "o888o   o88o  o888o 888oooo88  o88o  8  o88o o88o  o888o o88o    88 \n";

    
}
