#include <iostream>
using namespace std;
int main() {
    cout << "    |----------||@  \\\\   ___\n";
   cout << "    |____|_____|||_/_\\\\_|___|_\n";
    cout << " <|  ___\\    ||     | ____  |\n";
    cout << " <| /    |___||_____|/    | |\n";
    cout << " ||/  O  |__________/  O  |_||\n";

    
}
