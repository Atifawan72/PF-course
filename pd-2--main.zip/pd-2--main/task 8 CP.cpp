#include<iostream>
using namespace std;
int main(){
cout<<"                                                                       \n";
cout<<"     ............      ooooooo             o                ..........                 \n";
cout<<"      ...........     o        o        o     o             ........           \n";
cout<<"        .........              o        o     o             .......            \n";
cout<<"           ......             o         o     o             .....                \n";
cout<<"              ...            o          o     o             .....              \n";
cout<<"               ..          o            o     o  o     o    .......       \n";
cout<<"                .        o              o     o  o     o    ..........       \n";
cout<<"                      o ooooooooooo        o    o o o  oo o                   \n";
cout<<"                                                  o o  o  o       \n";
cout<<"                            oooooooooooooo                                         \n";
cout<<"                                   o   ooooooo              ooooooooooooo               \n";
cout<<"                                   o   o         o          o     o          \n";
cout<<"                                   o   o           o       o      o       \n";
cout<<"                                   o   ooooo         o   o        o               \n";
cout<<"                                   o   o               o          o              \n";
cout<<"                                   o   o             o    o       o                 \n";
cout<<"                                       ooooooo     o        o     o                              \n";
}