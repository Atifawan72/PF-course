#include<iostream>
using namespace std;

int main()
{
int num;
int sum(0);
cout<<"type first integer number: ";
cin>>num;
sum+=num;
cout<<"type second integer number: ";
cin>>num;
sum+=num;
cout<<"type third integer number: ";
cin>>num;
sum+=num;
cout<<"type fourth integer number: ";
cin>>num;
sum+=num;
cout<<"type fifth integer number: ";
cin>>num;
sum+=num;
cout<<"the sum of the number: "<<endl;
cout<<sum;
return 0;
}