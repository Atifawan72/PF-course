#include<iostream>
using namespace std;
void pf(){
int a;
cout<<"Enter your score: ";
cin>>a;
if(a > 50){
cout<<"Pass";
}
else
cout<<"Fail"; 
}
main(){
pf();
}